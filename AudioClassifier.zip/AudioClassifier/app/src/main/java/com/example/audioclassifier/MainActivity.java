package com.example.audioclassifier;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Arrays;

public class MainActivity extends Activity {

    // Requesting permission to RECORD_AUDIO
    private boolean permissionToRecordAccepted = false;
    private String[] permissions = {Manifest.permission.RECORD_AUDIO};
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;

    protected static final String TAG = "AudioClassifier";
    private int mAudioBufferSize;
    private int mAudioBufferSampleSize;
    private AudioRecord mAudioRecord;
    private boolean inRecordMode = false;

    Button btnStart, btnStop, btnAnalyse;
    TextView outputText;
    int recordingOffset = 0;
    Interpreter tflite;

    private static final int SAMPLE_RATE = 16000;
    private static final int SAMPLE_DURATION_MS = 10000; //10s
    private static final int RECORDING_LENGTH = (int) (SAMPLE_RATE * SAMPLE_DURATION_MS / 1000);
    private static final int RECORDING_SUBSET_LENGTH = (int) (SAMPLE_RATE * 2000 / 1000);
    short[] recordingBuffer = null;
    boolean showAnswer = false;



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecordAccepted) finish();

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Request permission from the user to record audio
        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);

        //Load tflite model
        try {
            tflite = new Interpreter(loadModelFile());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        btnAnalyse = findViewById(R.id.btnAnalyse);
        outputText = findViewById(R.id.answer);


        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                outputText.setText("");
                btnStart.setEnabled(false);
                btnStop.setEnabled(true);
                btnAnalyse.setEnabled(false);
                showAnswer = false;
                initAudioRecord();
                onResume();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnStart.setEnabled(true);
                btnStop.setEnabled(false);
                btnAnalyse.setEnabled(true);
                onPause();

            }
        });

        btnAnalyse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btnStart.setEnabled(false);
                btnStop.setEnabled(false);
                Toast.makeText(MainActivity.this, "The analysis may take up to 5s", Toast.LENGTH_SHORT).show();
                onAnalyze();
                btnStart.setEnabled(true);
                btnStop.setEnabled(true);
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        Log.v(TAG, "Resuming...");
        inRecordMode = true;

        Thread t = new Thread(new Runnable() {

            @Override
            public void run() {
                getSamples();
            }
        });
        t.start();
    }

    protected void onPause() {
        Log.v(TAG, "Pausing...");
        inRecordMode = false;
        super.onPause();

    }

    public void onAnalyze() {
        Log.v(TAG, "Analyzing...");
        inRecordMode = false;
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                classify();
            }
        });
        t1.start();

    }

    @Override
    protected void onDestroy() {
        Log.v(TAG, "Destroying...");
        if (mAudioRecord != null) {
            mAudioRecord.release();
            Log.v(TAG, "Released AudioRecord");
        }
        super.onDestroy();
    }


    private void initAudioRecord() {
        try {
            int channelConfig = AudioFormat.CHANNEL_IN_MONO;
            int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
            mAudioBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, channelConfig, audioFormat);
            mAudioBufferSampleSize = mAudioBufferSize / 2;
            mAudioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, channelConfig, audioFormat, mAudioBufferSize);
            Log.v(TAG, "Setup of AudioRecord okay. Buffer size = " + mAudioBufferSize);
            Log.v(TAG, "   Sample buffer size = " + mAudioBufferSampleSize);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }

        int audioRecordState = mAudioRecord.getState();
        if (audioRecordState != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord is not properly initialized");
            finish();
        } else {
            Log.v(TAG, "AudioRecord is initialized");
        }
    }

    private void getSamples() {
        if (mAudioRecord == null)
            return;

        short[] audioBuffer = new short[mAudioBufferSampleSize];
        recordingBuffer = new short[RECORDING_LENGTH];

        mAudioRecord.startRecording();
        recordingOffset= 0;

        int audioRecordingState = mAudioRecord.getRecordingState();
        if (audioRecordingState != AudioRecord.RECORDSTATE_RECORDING) {
            Log.e(TAG, "AudioRecord is not recording");
            finish();
        } else {
            Log.v(TAG, "AudioRecord has started recording...");
        }

        while (inRecordMode) {
            int samplesRead = mAudioRecord.read(audioBuffer, 0, mAudioBufferSampleSize);
            Log.v(TAG, "Got samples: " + samplesRead);
            Log.v(TAG, "First few sample values: " + audioBuffer[0] + ", "
                    + audioBuffer[1] + ", " + audioBuffer[2] + ", "
                    + audioBuffer[3] + ", " + audioBuffer[4] + ", "
                    + audioBuffer[5] + ", " + audioBuffer[6] + ", "
                    + audioBuffer[7] + ", " + audioBuffer[8] + ", "
                    + audioBuffer[9] + ", ");

            int maxLength = recordingBuffer.length;

            //save read data into an array
            try {
                if (recordingOffset + samplesRead < maxLength) {
                    System.arraycopy(audioBuffer, 0, recordingBuffer, recordingOffset, samplesRead);
                } else {
                    inRecordMode = false;
                }
                recordingOffset += samplesRead;
            } finally { }

        }

        mAudioRecord.stop();
        Log.v(TAG, "AudioRecord has stopped recording");
        Log.v(TAG, "Destroying...");
        if (mAudioRecord != null) {
            mAudioRecord.release();
            Log.v(TAG, "Released AudioRecord");
        }

    }

    private void classify() {
        Log.v(TAG, "Start recognition");

        //A
        short[] inputBuffer = new short[recordingBuffer.length];
        double[] doubleInputBuffer = new double[recordingBuffer.length];

        int maxLength = recordingBuffer.length;
        System.arraycopy(recordingBuffer, 0, inputBuffer, 0, maxLength);

        // We need to feed in float values between -1.0 and 1.0, so divide the signed 16-bit inputs.
        for (int i = 0; i < recordingBuffer.length; ++i) {
            doubleInputBuffer[i] = inputBuffer[i] / 32767.0;
        }
        //B


        //Uncomment the code below to analyse only the last 2 seconds of the recording and comment out code between
        // A and B above (note: app accuracy is lower when analysing only 2s)

        /*int maxLength = RECORDING_SUBSET_LENGTH;
        short[] inputBuffer = new short[maxLength];
        double[] doubleInputBuffer = new double[maxLength];
        int start = recordingOffset - RECORDING_SUBSET_LENGTH;

        try {
            System.arraycopy(recordingBuffer, start, inputBuffer, 0, maxLength);
        }catch(Exception e) {
            System.arraycopy(recordingBuffer, 0, inputBuffer, 0, maxLength);
        }

        // We need to feed in float values between -1.0 and 1.0, so divide the signed 16-bit inputs.
        for (int i = 0; i < inputBuffer.length; ++i) {
            doubleInputBuffer[i] = inputBuffer[i] / 32767.0;
        }*/

        //Extract MFCC features
        MFCC mfccConvert = new MFCC();
        double[][] mfccInput = mfccConvert.process(doubleInputBuffer);
        Log.v(TAG, "MFCC Input" + Arrays.toString(mfccInput));

        //Amend mfCCInput matrix to match the expect tensorflow model input
        double [][] averageMFCC= averageRow(mfccInput);
        double [][] mfccTransposed = transposeMatrix(averageMFCC);
        float[][] mfccFloat = toFloat(mfccTransposed);

        //Define new array to store model output
        float[][] labelProbArray = new float[1][3];
        tflite.run(mfccFloat, labelProbArray);
        Log.v(TAG, "PROBABILITIES===>" + matrixToString(labelProbArray));

        final String classification = result(labelProbArray);
        Log.v(TAG, "CLASSIFICATION===>" + classification);

        //Display classification on the screen
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                outputText.setText(classification);
            }
        });

        Log.v(TAG, "Destroying...");
        if (mAudioRecord != null) {
            mAudioRecord.release();
            Log.v(TAG, "Released AudioRecord");
        }

    }

    public String result(float[][] matrix){

        String answer = new String();
        int maxRow = getMaxRow(matrix);
        switch (maxRow) {
            case 0:
                answer = "You've recorded silence";
                break;
            case 1:
                answer = "You've recorded singing";
                break;
            case 2:
                answer = "You've recorded speech";
                break;
        }
        return answer;
    }

    public int getMaxRow(float[][] matrix) {
        float maxValue = matrix[0][0];
        int maxrow = 0;
        int n = matrix[0].length; //columns

        for (int j = 0; j < n; j++) { //looping through columns (3)
            for (int i = 0; i < 1; i++) { //looping through rows (1)
                if (matrix[i][j] > maxValue) {
                    maxValue = matrix[i][j];
                    maxrow = j;
                }
            }
        }
        return maxrow;
    }

    public static float[][] toFloat(double[][] matrix){

        int m = matrix[0].length; //columns
        int n = matrix.length; //rows
        float[][] FloatMatrix = new float[n][m];

        for(int x = 0; x < n; x++) {
            for (int y = 0; y < m; y++) {
                FloatMatrix[x][y]  = (float) matrix[x][y];
            }
        }
        return FloatMatrix;
    }

    public static double[][] averageRow(double[][] matrix){

        int m = matrix[0].length; //columns
        int n = matrix.length; //rows
        double sumRow;

        double[][] averageRowMatrix = new double[n][1];
        for(int x = 0; x < n; x++) {
            sumRow = 0;
            for (int y = 0; y < m; y++) {
                sumRow += matrix[x][y];
            }
            averageRowMatrix[x][0] = sumRow/m;
        }
        return averageRowMatrix;
    }

    public static double[][] transposeMatrix(double[][] matrix){
        int m = matrix.length;
        int n = matrix[0].length;

        double[][] transposedMatrix = new double[n][m];

        for(int x = 0; x < n; x++) {
            for(int y = 0; y < m; y++) {
                transposedMatrix[x][y] = matrix[y][x];
            }
        }
        return transposedMatrix;
    }

    public static String matrixToString(float[][] a){
        int m = a.length;
        int n = a[0].length;

        String tmp = "";
        for(int y = 0; y<m; y++){
            for(int x = 0; x<n; x++){
                tmp = tmp + a[y][x] + " ";
            }
            tmp = tmp + "\n";
        }
        return tmp;
    }

    public MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor = this.getAssets().openFd("model.tflite");
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }



}